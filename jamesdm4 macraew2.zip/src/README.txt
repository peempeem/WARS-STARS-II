All you need to do is use the programmer to flash the latest hardware compile. Then open the folder in src/software/ws2 and src/software/ws2_bsp in eclipse. Then download the elf file onto the FPGA.

To run the game, plug in a mouse into the USB port on the FPGA shield. If the game is stuck on the mouse screen (after moving the mouse or pressing its buttons), unplug and replug the mouse. (This sometimes happens if FPGA is powered off and on with the mouse attached).

Click the ships on the bottom and drag and drop them on the screen. They will automatically move towards the enemy and fight.

ENJOY :D
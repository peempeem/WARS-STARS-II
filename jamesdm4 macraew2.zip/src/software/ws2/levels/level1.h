#ifndef LEVEL1_H
#define LEVEL1_H

int run_level1();

#endif

#ifndef LOSE_H
#define LOSE_H

void run_lose();

#endif
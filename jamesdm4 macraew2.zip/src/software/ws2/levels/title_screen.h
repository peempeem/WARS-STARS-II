#ifndef TITLE_SCRREEN_H
#define TITLE_SCREEN_H

void run_title_screen();

#endif

#ifndef WIN_H
#define WIN_H

void run_win();

#endif